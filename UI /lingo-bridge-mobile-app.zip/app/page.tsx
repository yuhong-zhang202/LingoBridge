"use client"

import { useState, useCallback } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { AppHeader } from "@/components/app-header"
import { ElasticRecordButton } from "@/components/elastic-record-button"
import { FloatingTextInput } from "@/components/floating-text-input"

export default function LingoBridgePage() {
  const [isRecording, setIsRecording] = useState(false)
  const [recentEntry, setRecentEntry] = useState<string | null>(null)

  const handleRecordingStart = useCallback(() => {
    setIsRecording(true)
  }, [])

  const handleRecordingStop = useCallback(() => {
    setIsRecording(false)
    // Simulate a recorded entry
    setRecentEntry("Voice note recorded")
    setTimeout(() => setRecentEntry(null), 3000)
  }, [])

  const handleTextSubmit = useCallback((text: string) => {
    setRecentEntry(`"${text.slice(0, 30)}${text.length > 30 ? "..." : ""}"`)
    setTimeout(() => setRecentEntry(null), 3000)
  }, [])

  return (
    <main className="min-h-screen bg-background flex flex-col overflow-hidden relative">
      {/* Subtle ambient background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-32 -right-32 w-64 h-64 rounded-full bg-dusty-blue/5 blur-3xl" />
        <div className="absolute -bottom-32 -left-32 w-80 h-80 rounded-full bg-sage-green/5 blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-warm-beige/10 blur-3xl" />
      </div>

      {/* Header */}
      <AppHeader />

      {/* Main content area */}
      <div className="flex-1 flex flex-col items-center justify-center relative z-10 pb-32">
        {/* Soft greeting */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="mb-10 text-center px-8"
        >
          <p className="text-xl font-normal text-foreground/80 leading-relaxed text-balance">
            {"What's on your mind?"}
          </p>
        </motion.div>

        {/* Elastic record button */}
        <ElasticRecordButton
          onRecordingStart={handleRecordingStart}
          onRecordingStop={handleRecordingStop}
        />

        {/* Success feedback toast */}
        <AnimatePresence>
          {recentEntry && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.95 }}
              className="absolute bottom-44 left-1/2 -translate-x-1/2 px-4 py-2 rounded-full bg-sage-green/20 border border-sage-green/30 backdrop-blur-sm"
            >
              <p className="text-sm text-foreground/80 flex items-center gap-2">
                <svg className="w-4 h-4 text-sage-green" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                </svg>
                Entry saved
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Floating text input - positioned 20% from bottom */}
      <div className="absolute bottom-[20%] left-0 right-0 z-20">
        <AnimatePresence>
          {!isRecording && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
            >
              <FloatingTextInput onSubmit={handleTextSubmit} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Bottom navigation hint */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-8 text-muted-foreground/50"
      >
        <button className="p-2 hover:text-foreground/70 transition-colors">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
          </svg>
          <span className="sr-only">Journal entries</span>
        </button>
        <div className="w-1.5 h-1.5 rounded-full bg-dusty-blue/40" />
        <button className="p-2 hover:text-foreground/70 transition-colors">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-.94 1.11-.94h2.593c.55 0 1.02.398 1.11.94l.213 1.281c.063.374.313.686.645.87.074.04.147.083.22.127.324.196.72.257 1.075.124l1.217-.456a1.125 1.125 0 011.37.49l1.296 2.247a1.125 1.125 0 01-.26 1.431l-1.003.827c-.293.24-.438.613-.431.992a6.759 6.759 0 010 .255c-.007.378.138.75.43.99l1.005.828c.424.35.534.954.26 1.43l-1.298 2.247a1.125 1.125 0 01-1.369.491l-1.217-.456c-.355-.133-.75-.072-1.076.124a6.57 6.57 0 01-.22.128c-.331.183-.581.495-.644.869l-.213 1.28c-.09.543-.56.941-1.11.941h-2.594c-.55 0-1.02-.398-1.11-.94l-.213-1.281c-.062-.374-.312-.686-.644-.87a6.52 6.52 0 01-.22-.127c-.325-.196-.72-.257-1.076-.124l-1.217.456a1.125 1.125 0 01-1.369-.49l-1.297-2.247a1.125 1.125 0 01.26-1.431l1.004-.827c.292-.24.437-.613.43-.992a6.932 6.932 0 010-.255c.007-.378-.138-.75-.43-.99l-1.004-.828a1.125 1.125 0 01-.26-1.43l1.297-2.247a1.125 1.125 0 011.37-.491l1.216.456c.356.133.751.072 1.076-.124.072-.044.146-.087.22-.128.332-.183.582-.495.644-.869l.214-1.281z" />
            <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
          <span className="sr-only">Settings</span>
        </button>
      </motion.div>
    </main>
  )
}
