"use client"

import { useState, useRef, useCallback, useEffect, useMemo } from "react"
import { motion, useMotionValue, useTransform, useSpring, AnimatePresence } from "framer-motion"

interface ElasticRecordButtonProps {
  onRecordingStart?: () => void
  onRecordingStop?: () => void
}

// Generate organic blob path with smooth curves
function generateBlobPath(seed: number, variance: number = 0.15): string {
  const points = 8
  const angleStep = (Math.PI * 2) / points
  const baseRadius = 50
  
  const coords: { x: number; y: number }[] = []
  
  for (let i = 0; i < points; i++) {
    const angle = i * angleStep
    const randomOffset = Math.sin(seed + i * 1.5) * variance * baseRadius
    const radius = baseRadius + randomOffset
    coords.push({
      x: 50 + Math.cos(angle) * radius,
      y: 50 + Math.sin(angle) * radius,
    })
  }
  
  // Create smooth bezier curve through points
  let path = `M ${coords[0].x} ${coords[0].y}`
  
  for (let i = 0; i < coords.length; i++) {
    const current = coords[i]
    const next = coords[(i + 1) % coords.length]
    const nextNext = coords[(i + 2) % coords.length]
    
    const cp1x = current.x + (next.x - coords[(i - 1 + coords.length) % coords.length].x) * 0.25
    const cp1y = current.y + (next.y - coords[(i - 1 + coords.length) % coords.length].y) * 0.25
    const cp2x = next.x - (nextNext.x - current.x) * 0.25
    const cp2y = next.y - (nextNext.y - current.y) * 0.25
    
    path += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${next.x} ${next.y}`
  }
  
  return path + " Z"
}

export function ElasticRecordButton({ onRecordingStart, onRecordingStop }: ElasticRecordButtonProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [morphPhase, setMorphPhase] = useState(0)
  const constraintsRef = useRef<HTMLDivElement>(null)
  
  // Motion values for drag
  const dragY = useMotionValue(0)
  const springY = useSpring(dragY, { stiffness: 300, damping: 25 })
  
  // Calculate stretch based on drag distance
  const scaleY = useTransform(springY, [0, 120], [1, 1.5])
  const scaleX = useTransform(springY, [0, 120], [1, 0.8])
  const opacity = useTransform(springY, [0, 80, 120], [1, 0.95, 0.9])
  
  // Threshold to activate recording
  const ACTIVATION_THRESHOLD = 100

  // Liquid morphing animation
  useEffect(() => {
    if (isRecording) return
    
    const interval = setInterval(() => {
      setMorphPhase(prev => prev + 0.02)
    }, 50)
    
    return () => clearInterval(interval)
  }, [isRecording])

  // Generate multiple blob paths for morphing layers
  const blobPaths = useMemo(() => ({
    outer: generateBlobPath(morphPhase, 0.18),
    middle: generateBlobPath(morphPhase + 1, 0.15),
    inner: generateBlobPath(morphPhase + 2, 0.12),
    core: generateBlobPath(morphPhase + 3, 0.08),
  }), [morphPhase])

  const handleDrag = useCallback((_: unknown, info: { offset: { y: number } }) => {
    const clampedY = Math.max(0, Math.min(info.offset.y, 150))
    dragY.set(clampedY)
  }, [dragY])

  const handleDragEnd = useCallback((_: unknown, info: { offset: { y: number } }) => {
    if (info.offset.y > ACTIVATION_THRESHOLD) {
      setIsRecording(true)
      onRecordingStart?.()
    }
    dragY.set(0)
    setIsDragging(false)
  }, [dragY, onRecordingStart])

  const handleDragStart = useCallback(() => {
    setIsDragging(true)
  }, [])

  const stopRecording = useCallback(() => {
    setIsRecording(false)
    onRecordingStop?.()
  }, [onRecordingStop])

  return (
    <div className="relative flex flex-col items-center">
      {/* Instruction text */}
      <AnimatePresence mode="wait">
        {!isRecording && (
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="text-muted-foreground text-sm mb-6 text-center"
          >
            {isDragging ? "Keep pulling..." : "Pull down to record"}
          </motion.p>
        )}
      </AnimatePresence>

      {/* Drag area constraint */}
      <div ref={constraintsRef} className="relative h-[220px] flex items-start justify-center">
        <AnimatePresence mode="wait">
          {!isRecording ? (
            <motion.div
              key="button"
              drag="y"
              dragConstraints={{ top: 0, bottom: 150 }}
              dragElastic={0.1}
              onDrag={handleDrag}
              onDragStart={handleDragStart}
              onDragEnd={handleDragEnd}
              style={{
                scaleY,
                scaleX,
                opacity,
              }}
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 25 }}
              className="relative cursor-grab active:cursor-grabbing touch-none"
            >
              {/* Organic Liquid Blob Container */}
              <div className="w-44 h-44 relative flex items-center justify-center">
                
                {/* SVG Filter for frosted glass effect */}
                <svg className="absolute w-0 h-0">
                  <defs>
                    <filter id="goo" x="-50%" y="-50%" width="200%" height="200%">
                      <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur" />
                      <feColorMatrix in="blur" mode="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 19 -9" result="goo" />
                    </filter>
                    <filter id="grain">
                      <feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="4" result="noise" />
                      <feColorMatrix type="saturate" values="0" />
                      <feBlend in="SourceGraphic" in2="noise" mode="multiply" />
                    </filter>
                  </defs>
                </svg>

                {/* Outermost glow layer - very diffused */}
                <motion.div
                  className="absolute inset-0"
                  animate={{
                    scale: [1, 1.08, 1],
                    opacity: [0.2, 0.35, 0.2],
                  }}
                  transition={{
                    duration: 5,
                    repeat: Infinity,
                    ease: "easeInOut",
                  }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full blur-2xl">
                    <path
                      d={blobPaths.outer}
                      fill="oklch(0.65 0.06 250 / 0.3)"
                    />
                  </svg>
                </motion.div>

                {/* Second layer - soft dusty blue glow */}
                <motion.div
                  className="absolute inset-2"
                  animate={{
                    scale: [1, 1.06, 1],
                    opacity: [0.3, 0.5, 0.3],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 0.5,
                  }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full blur-xl">
                    <defs>
                      <linearGradient id="gradOuter" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="oklch(0.75 0.04 250 / 0.4)" />
                        <stop offset="100%" stopColor="oklch(0.65 0.06 250 / 0.3)" />
                      </linearGradient>
                    </defs>
                    <path d={blobPaths.middle} fill="url(#gradOuter)" />
                  </svg>
                </motion.div>

                {/* Third layer - frosted glass with warm gradient bloom */}
                <motion.div
                  className="absolute inset-4"
                  animate={{
                    scale: [1, 1.04, 1],
                    opacity: [0.5, 0.7, 0.5],
                  }}
                  transition={{
                    duration: 3.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1,
                  }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full blur-lg">
                    <defs>
                      <radialGradient id="gradMiddle" cx="50%" cy="70%" r="60%">
                        <stop offset="0%" stopColor="oklch(0.88 0.08 85 / 0.5)" />
                        <stop offset="40%" stopColor="oklch(0.85 0.10 60 / 0.3)" />
                        <stop offset="100%" stopColor="oklch(0.65 0.06 250 / 0.4)" />
                      </radialGradient>
                    </defs>
                    <path d={blobPaths.inner} fill="url(#gradMiddle)" />
                  </svg>
                </motion.div>

                {/* Fourth layer - inner frosted core */}
                <motion.div
                  className="absolute inset-6"
                  animate={{
                    scale: [1, 1.03, 1],
                    opacity: [0.6, 0.85, 0.6],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1.5,
                  }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full blur-md">
                    <defs>
                      <radialGradient id="gradInner" cx="50%" cy="65%" r="50%">
                        <stop offset="0%" stopColor="oklch(0.95 0.02 85 / 0.7)" />
                        <stop offset="50%" stopColor="oklch(0.88 0.08 85 / 0.4)" />
                        <stop offset="100%" stopColor="oklch(0.75 0.04 250 / 0.5)" />
                      </radialGradient>
                    </defs>
                    <path d={blobPaths.core} fill="url(#gradInner)" />
                  </svg>
                </motion.div>

                {/* Inner bright core - warm accent bloom */}
                <motion.div
                  className="absolute inset-8"
                  animate={{
                    scale: [1, 1.02, 1],
                    opacity: [0.7, 0.95, 0.7],
                  }}
                  transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 2,
                  }}
                >
                  <svg viewBox="0 0 100 100" className="w-full h-full blur-sm">
                    <defs>
                      <radialGradient id="gradCore" cx="50%" cy="60%" r="45%">
                        <stop offset="0%" stopColor="oklch(0.98 0.01 85 / 0.9)" />
                        <stop offset="40%" stopColor="oklch(0.90 0.06 75 / 0.6)" />
                        <stop offset="100%" stopColor="oklch(0.80 0.05 250 / 0.5)" />
                      </radialGradient>
                    </defs>
                    <path d={blobPaths.core} fill="url(#gradCore)" />
                  </svg>
                </motion.div>

                {/* Subtle grain texture overlay */}
                <div 
                  className="absolute inset-10 rounded-full opacity-[0.03] mix-blend-overlay pointer-events-none"
                  style={{
                    backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
                  }}
                />

                {/* Sharp center backdrop for icon contrast */}
                <div className="absolute inset-12 rounded-full bg-gradient-to-b from-white/70 via-white/50 to-pale-gold/30 backdrop-blur-[1px]" />

                {/* Microphone icon - sharp and clear */}
                <svg
                  className="w-9 h-9 text-dusty-blue relative z-10 drop-shadow-sm"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={2}
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z"
                  />
                </svg>
              </div>

              {/* Drag indicator dots */}
              <motion.div 
                className="flex justify-center gap-1 mt-3"
                animate={{ opacity: isDragging ? 0.3 : 0.5 }}
              >
                <span className="w-1 h-1 rounded-full bg-dusty-blue/40" />
                <span className="w-1 h-1 rounded-full bg-dusty-blue/40" />
                <span className="w-1 h-1 rounded-full bg-dusty-blue/40" />
              </motion.div>
            </motion.div>
          ) : (
            <motion.div
              key="recording"
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="flex flex-col items-center"
            >
              {/* Recording waveform visualization */}
              <WaveformVisualizer onStop={stopRecording} />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

function WaveformVisualizer({ onStop }: { onStop: () => void }) {
  const [bars] = useState(() => Array.from({ length: 24 }, () => Math.random()))
  
  return (
    <div className="flex flex-col items-center gap-6">
      {/* Waveform bars */}
      <div className="flex items-center justify-center gap-1 h-32 px-4">
        {bars.map((baseHeight, i) => (
          <WaveformBar key={i} index={i} baseHeight={baseHeight} />
        ))}
      </div>

      {/* Recording indicator */}
      <div className="flex items-center gap-2 text-foreground/70">
        <motion.div
          className="w-2.5 h-2.5 rounded-full bg-sage-green"
          animate={{ opacity: [1, 0.4, 1] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: "easeInOut" }}
        />
        <span className="text-sm font-medium">Recording...</span>
        <RecordingTimer />
      </div>

      {/* Stop button */}
      <motion.button
        onClick={onStop}
        className="w-16 h-16 rounded-full bg-dusty-blue flex items-center justify-center shadow-lg shadow-dusty-blue/20 hover:shadow-xl hover:shadow-dusty-blue/30 transition-shadow"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <div className="w-5 h-5 rounded-sm bg-primary-foreground" />
      </motion.button>
    </div>
  )
}

function WaveformBar({ index, baseHeight }: { index: number; baseHeight: number }) {
  const minHeight = 20 + baseHeight * 30
  const maxHeight = 60 + baseHeight * 40
  
  return (
    <motion.div
      className="w-1.5 rounded-full bg-dusty-blue"
      animate={{
        height: [minHeight, maxHeight, minHeight],
      }}
      transition={{
        duration: 0.6 + Math.random() * 0.4,
        repeat: Infinity,
        delay: index * 0.05,
        ease: "easeInOut",
      }}
    />
  )
}

function RecordingTimer() {
  const [seconds, setSeconds] = useState(0)
  
  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds(s => s + 1)
    }, 1000)
    return () => clearInterval(interval)
  }, [])

  const minutes = Math.floor(seconds / 60)
  const secs = seconds % 60
  
  return (
    <span className="text-sm tabular-nums text-muted-foreground">
      {String(minutes).padStart(2, '0')}:{String(secs).padStart(2, '0')}
    </span>
  )
}
