"use client"

import { motion } from "framer-motion"

export function AppHeader() {
  return (
    <header className="flex items-center justify-between px-6 pt-14 pb-4">
      {/* Menu button */}
      <motion.button
        className="p-2 -ml-2 text-foreground/70 hover:text-foreground transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <svg
          className="w-6 h-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={1.5}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
          />
        </svg>
        <span className="sr-only">Menu</span>
      </motion.button>

      {/* Logo */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col items-center"
      >
        <h1 className="text-lg font-semibold text-foreground tracking-tight">
          LingoBridge
        </h1>
        <p className="text-xs text-muted-foreground">Voice Journal</p>
      </motion.div>

      {/* Profile button */}
      <motion.button
        className="w-9 h-9 rounded-full bg-sage-green/20 flex items-center justify-center text-sage-green"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <svg
          className="w-5 h-5"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={1.5}
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z"
          />
        </svg>
        <span className="sr-only">Profile</span>
      </motion.button>
    </header>
  )
}
