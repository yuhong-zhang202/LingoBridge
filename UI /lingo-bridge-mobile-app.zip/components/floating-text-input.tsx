"use client"

import React from "react"

import { useState } from "react"
import { motion } from "framer-motion"

interface FloatingTextInputProps {
  onSubmit?: (text: string) => void
}

export function FloatingTextInput({ onSubmit }: FloatingTextInputProps) {
  const [value, setValue] = useState("")
  const [isFocused, setIsFocused] = useState(false)

  const handleSubmit = () => {
    if (value.trim()) {
      onSubmit?.(value.trim())
      setValue("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3, duration: 0.5 }}
      className="w-full max-w-sm mx-auto px-6"
    >
      <div
        className={`
          relative flex items-center gap-3 px-5 py-4 rounded-2xl
          backdrop-blur-xl bg-card/60 border border-border/50
          shadow-lg shadow-foreground/5
          transition-all duration-300
          ${isFocused ? "bg-card/80 border-dusty-blue/30 shadow-xl" : ""}
        `}
      >
        {/* Text input */}
        <input
          type="text"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onKeyDown={handleKeyDown}
          placeholder="Or type your thoughts..."
          className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground/60 text-sm outline-none"
        />

        {/* Send button */}
        <motion.button
          onClick={handleSubmit}
          disabled={!value.trim()}
          className="p-2 rounded-full bg-dusty-blue/10 text-dusty-blue disabled:opacity-30 disabled:cursor-not-allowed transition-colors hover:bg-dusty-blue/20"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <svg
            className="w-4 h-4"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M6 12L3.269 3.126A59.768 59.768 0 0121.485 12 59.77 59.77 0 013.27 20.876L5.999 12zm0 0h7.5"
            />
          </svg>
        </motion.button>
      </div>
    </motion.div>
  )
}
